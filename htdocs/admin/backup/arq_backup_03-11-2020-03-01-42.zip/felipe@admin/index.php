<?php
header('location: ../');